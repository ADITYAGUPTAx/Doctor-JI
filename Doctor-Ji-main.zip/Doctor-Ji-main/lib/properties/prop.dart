import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

// color info
const rang1 = Color.fromARGB(255, 250, 250, 250);
const rang1Text = Color.fromARGB(200, 250, 250, 250);
const rang2 = Color.fromARGB(255, 239, 239, 239);
const rang3 = Color.fromARGB(255, 0, 206, 206);
const rang4 = Color.fromARGB(255, 0, 168, 168);
const rang5 = Color.fromARGB(255, 50, 64, 71);
const rang6 = Color.fromARGB(255, 211, 211, 211);

// text style


// screen size
// double screenWidth = MediaQuery.of(context).size.width;
// double screenheight = MediaQuery.of(context).size.height;
