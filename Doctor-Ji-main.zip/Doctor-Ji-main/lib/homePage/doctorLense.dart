import 'package:flutter/material.dart';

class doctorLense extends StatefulWidget {
  const doctorLense({super.key});

  @override
  State<doctorLense> createState() => _doctorLenseState();
}

class _doctorLenseState extends State<doctorLense> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}